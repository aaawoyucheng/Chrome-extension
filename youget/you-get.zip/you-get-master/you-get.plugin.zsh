#!/usr/bin/env zsh
alias you-get="noglob $(dirname $0)/you-get"
alias you-vlc="noglob $(dirname $0)/you-get --player vlc"
